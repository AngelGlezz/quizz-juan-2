<?php
	$metas = array(
		"Martinoli" => array(
			"title" => "A qué comentarista te pareces más",
			"description" => "¡¿De qué te vas a disfraza?!",
			"image" => "images/metas/0.png" 
		),
		"Bermudez" => array(
			"title" => "A qué comentarista te pareces más",
			"description" => "¡Uff, uff y recontra uff!",
			"image" => "images/metas/1.png" 
		),
		"Orvananos" => array(
			"title" => "A qué comentarista te pareces más",
			"description" => "¡Eres una fieraaaaa!",
			"image" => "images/metas/2.png" 
		),
		"Tapia" => array(
			"title" => "A qué comentarista te pareces más",
			"description" => "Europeo sudamericano",
			"image" => "images/metas/3.png" 
		),
		"Fernandez" => array(
			"title" => "A qué comentarista te pareces más",
			"description" => "Todo un clásico",
			"image" => "images/metas/4.png" 
		),
		"Pollo" => array(
			"title" => "A qué comentarista te pareces más",
			"description" => "Nueva generación",
			"image" => "images/metas/5.png" 
		)
	);